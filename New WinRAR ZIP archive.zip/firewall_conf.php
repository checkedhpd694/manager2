<?
$fw_conf['max_lockcount']=10;
$fw_conf['max_connect']=50;
$fw_conf['time_limit']=3;
$fw_conf['time_wait']=20;
$fw_conf['htaccess']="./firewall/htaccess";
?>