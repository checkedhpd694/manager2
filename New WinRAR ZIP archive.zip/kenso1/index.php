<a href="add.php">Add token</a>
<br>
<a href="del.php">Del token</a>
<br>
<a href="reaction.php">Reaction</a>
<br>
<a href="viplike.php">Vip like</a>